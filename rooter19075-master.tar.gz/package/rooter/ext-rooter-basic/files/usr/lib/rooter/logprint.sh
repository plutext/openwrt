#!/bin/sh
#

logger -t "Log Print " "$@"
exit 0
