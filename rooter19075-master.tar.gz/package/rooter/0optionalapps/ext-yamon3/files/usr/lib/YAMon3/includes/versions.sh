##########################################################################
# Yet Another Monitor (YAMon)
# Copyright (c) 2013-present Al Caughey
# All rights reserved.
#
# History
# 2018-02-04: updated to 3.4.0
# 2018-02-10: updated to 3.4.1
# 2018-02-23: updated to 3.4.2
# 2018-03-09: updated to 3.4.3
# 2018-03-23: updated to 3.4.4
# 2018-07-10: updated to 3.4.5
# 2019-01-22: updated to 3.4.6
# 2019-01-29: updated to 3.4.7
# 2019-04-19: updated to 3.4.8

_version='3.4.7'
_file_version='3.4'
